// script.js - You can add any JavaScript functionality here.
// For example, you could add a smooth scrolling effect.
